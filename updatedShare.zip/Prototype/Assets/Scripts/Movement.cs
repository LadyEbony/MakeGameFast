﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour {

	public bool inTheAir = false;
	public float jumpHeight = 10f;
	private float speed = 0f;

	public float acceleration = 2f;
	public float friction = 0.5f;
	public float maxSpeed = 7f;

	public bool grounded;

	public float drag = 1.5f;
	private Rigidbody2D myRigidbody;
	private float h;

	void Start () 
	{
		myRigidbody = gameObject.GetComponent<Rigidbody2D> ();
		drag = myRigidbody.drag;
	}


	void FixedUpdate()
	{
		h = Input.GetAxisRaw ("Horizontal");

		if ((h) > 0) {
			speed += acceleration;
		}
		else if ((h) < 0) {
			speed -= acceleration;
		}

		if (speed >= maxSpeed) {
			speed = maxSpeed;
		}
		else if (speed <= -maxSpeed) {
			speed = -maxSpeed;
		}


	}


	void OnCollisionEnter2D(Collision2D coll)
	{
		if (coll.gameObject.tag == "Floor") {
			inTheAir = false;
		} else {
			inTheAir = true;
		}
	}

	void OnCollisionExit2D(Collision2D coll){
		if (coll.gameObject.tag == "Floor") {
			inTheAir = true;
		} else {
			inTheAir = false;
		}
	}

	void Update()
	{

		myRigidbody.AddForce ((Vector2.right * speed));

		if (Input.GetKeyDown (KeyCode.Space) && inTheAir == false) {

			myRigidbody.velocity = new Vector2 (0, jumpHeight);
		}


		if (h == 0) {
			
			if (speed > 0) {
				speed -= friction;
				if (speed < 0) {
					speed = 0;
				}

			} else if (speed < 0) {
				speed += friction;
				if (speed > 0) {
					speed = 0;
				}
			}

			drag = 50f;
		} else {
			drag = 0f;
		}
	}


}
