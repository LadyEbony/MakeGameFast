﻿using UnityEngine;
using System.Collections;

public class despawn : MonoBehaviour {

    public float despawnRate = 5f;
    private float despawni = 0f;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        despawni += Time.deltaTime;
        if (despawni >= despawnRate)
            Destroy(this.gameObject);
    }
}
