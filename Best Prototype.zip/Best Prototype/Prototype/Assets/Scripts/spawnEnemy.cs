﻿using UnityEngine;
using System.Collections;

public class spawnEnemy : MonoBehaviour {

    public GameObject enemy;
    public float spawnRate = 1f;
    private float spawni = 0f;

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        spawni += Time.deltaTime;
        if (spawni >= spawnRate)
        {
            Instantiate(enemy, transform.position, Quaternion.Euler(0, 0, 0));
            spawni = 0;
        }
    }
}
