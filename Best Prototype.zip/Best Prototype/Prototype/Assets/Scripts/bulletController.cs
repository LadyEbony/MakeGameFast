﻿using UnityEngine;
using System.Collections;

public class bulletController : MonoBehaviour {

    public float bulletspeed = 7f;
    Rigidbody2D myRig;

	// Use this for initialization
	void Start () {

        transform.Rotate(0, 0, -90);

        myRig = GetComponent<Rigidbody2D>();

        float radians = transform.rotation.eulerAngles.z * (Mathf.PI / 180);

        myRig.AddForce(new Vector2(Mathf.Cos(radians), Mathf.Sin(radians)) * bulletspeed * Time.deltaTime, ForceMode2D.Impulse);
	}
	
	// Update is called once per frame
	void Update () {

	}
}
