﻿using UnityEngine;
using System.Collections;

public class KillingScript : MonoBehaviour {

	public GameObject Enemy;

	// Use this for initialization
	void Start () {
		Enemy = GameObject.FindGameObjectWithTag ("Enemy");
	}




	void OnCollisionEnter2D (Collision2D coll)
	{
		if (coll.gameObject.tag == "Enemy") {
			//Destroy Enemy
			Destroy(GameObject.FindGameObjectWithTag("Enemy"));
		}
	}

	// Update is called once per frame
	void Update () {
		
	}
}
