﻿using UnityEngine;
using System.Collections;

public class CameraFollow : MonoBehaviour {

	public float m_speed = 0.1f;
	public float cam_height_divided = 80f;
	public Transform target;
	Camera MainCam;

	// Use this for initialization
	void Start () {

		MainCam = GetComponent<Camera> ();

	}

	// Update is called once per frame
	void Update () {

		MainCam.orthographicSize = (Screen.height / cam_height_divided) / 4f;

		if (target) {

			transform.position = Vector3.Lerp (transform.position, target.position, m_speed) + new Vector3 (0, 0, -10);
		}

	}
}